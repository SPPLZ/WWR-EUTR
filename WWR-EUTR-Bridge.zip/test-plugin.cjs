const {test}=require('node:test'),assert=require('node:assert/strict'),path=require('node:path'),crypto=require('node:crypto');
const {inspectPlugin}=require('./plugin-status.cjs');
const game=path.resolve('test-game'),exe=path.join(game,'bin','win_x64','eurotrucks2.exe'),dll=path.join(game,'bin','win_x64','plugins','local-radio.dll'),data=Buffer.from('plugin');
const expectedHash=crypto.createHash('sha256').update(data).digest('hex');
function scan(files,extra={}){return inspectPlugin({gamePath:game,expectedHash,...extra,io:{existsSync:p=>files.has(p),readFileSync:p=>{if(!files.has(p))throw Error('missing');return files.get(p)}}});}
test('missing game is unknown installation, not missing plugin',()=>assert.equal(scan(new Map()).status,'game-not-found'));
test('existing game without DLL is missing',()=>assert.equal(scan(new Map([[exe,'']])).status,'missing'));
test('matching DLL is installed',()=>assert.equal(scan(new Map([[exe,''],[dll,data]])).status,'installed'));
test('different DLL is never overwritten',()=>assert.equal(scan(new Map([[exe,''],[dll,Buffer.from('other')]])).status,'different'));
test('Steam library paths are discovered',()=>{const root=path.resolve('steam'),library=path.resolve('other-library'),g=path.join(library,'steamapps','common','Euro Truck Simulator 2');const files=new Map([[path.join(root,'steamapps','libraryfolders.vdf'),'"path" "'+library.replaceAll('\\','\\\\')+'"'],[path.join(g,'bin','win_x64','eurotrucks2.exe'),''],[path.join(g,'bin','win_x64','plugins','local-radio.dll'),data]]);assert.equal(scan(files,{steamRoots:[root]}).status,'installed');});
