const http=require('node:http'),crypto=require('node:crypto');
const PORT=8772;
function createBridge({getState,siteURL='http://127.0.0.1:8771/',port=PORT,now=Date.now}={}){
  const own=`http://127.0.0.1:${port}`,allowed=new Set([own,new URL(siteURL).origin]);
  const code=String(crypto.randomInt(0,1000000)).padStart(6,'0'),sessions=new Map();let failures=[];
  const approvalNonce=crypto.randomBytes(32).toString("hex");
  function issue(origin){for(const [t,v] of sessions)if(v.expires<now())sessions.delete(t);if(sessions.size>=20)sessions.delete(sessions.keys().next().value);const token=crypto.randomBytes(32).toString("hex");sessions.set(token,{origin,expires:now()+86400000});return token;}
  const server=http.createServer(async(req,res)=>{
    res.setHeader('Cache-Control','no-store');res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('X-Frame-Options','DENY');res.setHeader('Referrer-Policy','same-origin');
    const json=(status,data)=>{res.writeHead(status,{'Content-Type':'application/json; charset=utf-8'});res.end(JSON.stringify(data));};
    if(req.headers.host!==`127.0.0.1:${port}`)return json(403,{error:'host'});
    const origin=req.headers.origin;
    if(origin&&!allowed.has(origin))return json(403,{error:'origin'});
    if(origin){res.setHeader('Access-Control-Allow-Origin',origin);res.setHeader('Vary','Origin');}
    if(req.method==='OPTIONS'){
      if(!origin)return json(403,{error:'origin'});
      res.setHeader('Access-Control-Allow-Methods','GET, POST, OPTIONS');res.setHeader('Access-Control-Allow-Headers','Content-Type, Authorization');res.setHeader('Access-Control-Allow-Private-Network','true');res.writeHead(204);return res.end();
    }
    if(req.url==='/api/status'&&req.method==='GET')return json(200,{app:'WWR-EUTR Bridge',version:'1.0.0'});
    if(req.url==='/'&&req.method==='GET'){
      res.writeHead(200,{'Content-Type':'text/html; charset=utf-8','Content-Security-Policy':`default-src 'none'; style-src 'unsafe-inline'; form-action 'self' ${new URL(siteURL).origin}; frame-ancestors 'none'`});
      return res.end(`<!doctype html><html lang="ko"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>WWR-EUTR 연결 승인</title><style>body{font:16px system-ui;background:#171b1a;color:#edf1ee;max-width:480px;margin:12vh auto;padding:24px}h1{font-size:26px}p{line-height:1.8;color:#bdc8c1}button{padding:14px 22px;background:#a4cbb5;color:#112019;border:0;border-radius:8px;font:600 16px system-ui;cursor:pointer}</style><h1>WWR-EUTR와 연결할까요?</h1><p>현재 게임의 국가 정보를 WWR-EUTR에 연결합니다.<br>연결 코드를 입력할 필요가 없습니다.</p><form action="/approve" method="post"><input type="hidden" name="nonce" value="${approvalNonce}"><button type="submit">연결하고 WWR-EUTR 열기</button></form><p>연결은 이 브라우저 탭에서 기억합니다.<br>프로그램을 다시 실행하거나 연결이 만료되면 다시 승인하세요.</p></html>`);
    }
    if(req.url==='/approve'&&req.method==='POST'){
      if(origin!==own)return json(403,{error:'origin'});
      let raw='';for await(const chunk of req){raw+=chunk;if(Buffer.byteLength(raw)>1024)return json(413,{error:'size'});}
      if(new URLSearchParams(raw).get('nonce')!==approvalNonce)return json(403,{error:'approval'});
      const target=new URL(siteURL);target.hash='wwreutr-token='+issue(target.origin);
      res.writeHead(303,{Location:target.href});return res.end();
    }
    if(req.url==='/api/pair'&&req.method==='POST'){
      if(!origin)return json(403,{error:'origin'});
      failures=failures.filter(t=>now()-t<60000);if(failures.length>=5)return json(429,{error:'잠시 후 다시 시도하세요'});
      if(!String(req.headers['content-type']).startsWith('application/json'))return json(415,{error:'content type'});
      let raw='';try{for await(const chunk of req){raw+=chunk;if(Buffer.byteLength(raw)>1024)return json(413,{error:'size'});}const body=JSON.parse(raw);if(body.code!==code){failures.push(now());return json(401,{error:'연결 코드를 확인하세요'});}}catch{return json(400,{error:'body'});}
      for(const [token,s]of sessions)if(s.expires<now())sessions.delete(token);
      if(sessions.size>=20)sessions.delete(sessions.keys().next().value);
      const token=crypto.randomBytes(32).toString('hex');sessions.set(token,{origin,expires:now()+24*60*60*1000});return json(200,{token});
    }
    if(req.url==='/api/telemetry'&&req.method==='GET'){
      const token=String(req.headers.authorization||'').replace(/^Bearer /,'');const session=sessions.get(token);
      if(!session||session.origin!==origin||session.expires<now())return json(401,{error:'다시 연결하세요'});
      const s=getState();
      return json(200,{connected:!!s.connected,paused:!!s.paused,game:s.game||0,revision:s.revision||0,outOfRange:!!s.outOfRange,region:s.region?{name:s.region.name,country:s.region.country}:null});
    }
    return json(404,{error:'not found'});
  });
  server.requestTimeout=5000;server.headersTimeout=5000;
  return {server,code};
}
module.exports={createBridge};

