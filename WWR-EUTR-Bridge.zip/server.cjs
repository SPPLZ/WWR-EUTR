const fs=require('fs'),path=require('path'),{spawn}=require('child_process'),{createInterface}=require('readline');
const {createBridge}=require('./bridge.cjs'),{RegionTracker}=require('./region.cjs');
const {inspectPlugin}=require('./plugin-status.cjs');
const config=JSON.parse(fs.readFileSync(path.join(__dirname,'config.json'))),tracker=new RegionTracker(require('./cities.json'));
let state={connected:false,region:null},lastSample=0;
const reader=spawn('powershell.exe',['-NoProfile','-ExecutionPolicy','Bypass','-File',path.join(__dirname,'read-telemetry.ps1')],{windowsHide:true,stdio:['ignore','pipe','pipe']});
createInterface({input:reader.stdout}).on('line',line=>{try{const sample=JSON.parse(line);lastSample=Date.now();state={...sample,...tracker.update(sample)};}catch{}});
reader.on('error',e=>console.error(e.message));reader.stderr.on('data',b=>console.error(String(b)));reader.on('exit',()=>{state.connected=false;});
let pluginCache,pluginChecked=0;
function getPlugin(){
  if(state.game===1&&state.revision===12&&Date.now()-lastSample<3000)return {status:'active'};
  if(!pluginCache||Date.now()-pluginChecked>3000){pluginChecked=Date.now();pluginCache=inspectPlugin({gamePath:config.gamePath,steamRoots:[config.steamPath,path.join(process.env['ProgramFiles(x86)']||'C:/Program Files (x86)','Steam'),path.join(process.env.ProgramFiles||'C:/Program Files','Steam')],expectedHash:require('./vendor/source.json').dllSha256});}
  return pluginCache;
}
const {server}=createBridge({siteURL:config.siteURL,getPlugin,getState:()=>({...state,connected:state.connected&&Date.now()-lastSample<3000})});
server.listen(8772,'127.0.0.1',()=>console.log('WWR-EUTR Bridge: http://127.0.0.1:8772/'));
server.on('error',e=>{console.error(e.message);reader.kill();process.exitCode=1;});
function stop(){reader.kill();server.close(()=>process.exit());}process.on('SIGINT',stop);process.on('SIGTERM',stop);process.on('exit',()=>reader.kill());
