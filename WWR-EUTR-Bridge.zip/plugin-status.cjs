const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
function inspectPlugin({gamePath,steamRoots=[],expectedHash,io=fs}={}){
  const roots=new Set(steamRoots.filter(Boolean)),games=new Set(gamePath?[gamePath]:[]);
  for(const root of [...roots]){
    try{const vdf=io.readFileSync(path.join(root,'steamapps','libraryfolders.vdf'),'utf8');for(const m of vdf.matchAll(/"path"\s*"([^"]+)"/g))roots.add(m[1].replaceAll('\\\\','\\'));}catch{}
  }
  for(const root of roots)games.add(path.join(root,'steamapps','common','Euro Truck Simulator 2'));
  let found=false,unreadable=false;
  for(const game of games){
    if(!io.existsSync(path.join(game,'bin','win_x64','eurotrucks2.exe')))continue;
    found=true;
    const dll=path.join(game,'bin','win_x64','plugins','local-radio.dll');
    if(!io.existsSync(dll))continue;
    try{const hash=crypto.createHash('sha256').update(io.readFileSync(dll)).digest('hex');return {status:hash===expectedHash?'installed':'different'};}catch{unreadable=true;}
  }
  return {status:unreadable?'unknown':found?'missing':'game-not-found'};
}
module.exports={inspectPlugin};
