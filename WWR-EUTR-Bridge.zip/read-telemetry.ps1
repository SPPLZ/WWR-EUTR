param([string]$MapName = 'Local\ETS2LocalRadio', [int]$SampleLimit = 0)
$ErrorActionPreference = 'Stop'
$radioSamples = 0
Add-Type -AssemblyName System.Core
$radioMap = $null
$radioView = $null
$radioTimestamp = $null
$radioLastChange = [DateTime]::UtcNow
while ($true) {
    try {
        if ($null -eq $radioMap) {
            $radioMap = [IO.MemoryMappedFiles.MemoryMappedFile]::OpenExisting($MapName, [IO.MemoryMappedFiles.MemoryMappedFileRights]::Read)
            $radioView = $radioMap.CreateViewAccessor(0, 32768, [IO.MemoryMappedFiles.MemoryMappedFileAccess]::Read)
        }
        $radioRevision = $radioView.ReadUInt32(40)
        $radioTick = $radioView.ReadUInt64(8)
        if ($radioTick -ne $radioTimestamp) { $radioLastChange = [DateTime]::UtcNow; $radioTimestamp = $radioTick }
        $radioFresh = ([DateTime]::UtcNow - $radioLastChange).TotalSeconds -lt 5
        $radioState = @{
            connected = ($radioView.ReadBoolean(0) -and $radioFresh -and $radioRevision -eq 12)
            paused = $radioView.ReadBoolean(4)
            revision = $radioRevision
            game = $radioView.ReadUInt32(52)
            x = $radioView.ReadDouble(2200)
            z = $radioView.ReadDouble(2216)
        }
        $radioState | ConvertTo-Json -Compress
    } catch {
        if ($null -ne $radioView) { $radioView.Dispose(); $radioView = $null }
        if ($null -ne $radioMap) { $radioMap.Dispose(); $radioMap = $null }
        '{"connected":false,"paused":false,"game":0}'
    }
    $radioSamples++
    if ($SampleLimit -gt 0 -and $radioSamples -ge $SampleLimit) { break }
    Start-Sleep -Milliseconds 500
}
if ($null -ne $radioView) { $radioView.Dispose() }
if ($null -ne $radioMap) { $radioMap.Dispose() }
