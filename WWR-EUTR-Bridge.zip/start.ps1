$ErrorActionPreference = 'Stop'
try {
    $radioExisting = Invoke-RestMethod -Uri 'http://127.0.0.1:8772/api/status' -TimeoutSec 2
    if ($radioExisting.app -eq 'WWR-EUTR Bridge') { Start-Process 'https://spplz.github.io/WWR-EUTR/'; exit }
} catch {}
$radioNode = Get-Command node.exe -ErrorAction SilentlyContinue
$radioNodePath = if ($radioNode) { $radioNode.Source } else { Join-Path $env:USERPROFILE '.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe' }
if (-not (Test-Path -LiteralPath $radioNodePath)) { throw 'Install Node.js 22 or later from https://nodejs.org/' }
Start-Process -FilePath $radioNodePath -ArgumentList ('"' + (Join-Path $PSScriptRoot 'server.cjs') + '"') -WorkingDirectory $PSScriptRoot -WindowStyle Hidden -RedirectStandardOutput (Join-Path $PSScriptRoot 'server.log') -RedirectStandardError (Join-Path $PSScriptRoot 'server-error.log')
Start-Sleep -Seconds 2
Start-Process 'https://spplz.github.io/WWR-EUTR/'
